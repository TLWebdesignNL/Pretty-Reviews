# Pretty Reviews
Pretty Reviews Module for Joomla 4 & Joomla 5
